package com.capgemini.PromoRest.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.PromoRest.dao.DiscountDao;
import com.capgemini.PromoRest.model.Discount;

@Service("discountservice")
@Transactional
public class DiscountServiceImpl implements DiscountService {
	
	@Autowired
	private DiscountDao discountdao;

	@Override
	public List<Discount> getAll() {
		return discountdao.findAll();
	}

}
