package discountAndPromos;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs {

	

@Given("^Admin \\(or\\) Merchant Login Credentials$")
public void admin_or_Merchant_Login_Credentials() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^Login details are validated$")
public void login_details_are_validated() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^Discounts and promos can be applied on a particular product or category of products for a limited time period\\.$")
public void discounts_and_promos_can_be_applied_on_a_particular_product_or_category_of_products_for_a_limited_time_period() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}
}
