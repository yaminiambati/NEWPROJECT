package com.capgemini.DiscountDemo.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.capgemini.DiscountDemo.model.Discount;

@Controller
public class MyController {
	@RequestMapping("/")
	public String Disp(ModelMap map) {
		//List<Pilot> pilots= pilotService.getAll();
		
				final String uri="http://localhost:8089/PromoRest/api/v2/discounts";
				RestTemplate restTemplate=new RestTemplate();
				
				Discount[] discounts= restTemplate.getForObject(uri, Discount[].class);
				
				map.put("discounts",discounts);
				map.put("discount", new Discount());
				
		return "discountpromos";
		
	}
}