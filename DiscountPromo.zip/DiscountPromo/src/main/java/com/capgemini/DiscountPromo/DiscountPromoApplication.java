package com.capgemini.DiscountPromo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiscountPromoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiscountPromoApplication.class, args);
	}
}
