package com.capgemini.PromoDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PromoDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PromoDemoApplication.class, args);
	}
}
