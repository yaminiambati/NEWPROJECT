package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginBean {

	WebDriver driver;
	@FindBy(name="userName")
	private WebElement UserName;
	
	@FindBy(name="userPwd")
	private WebElement UserPwd;
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
	private WebElement btn;
	
	public LoginBean(WebDriver driver) {
		
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setBtn() {
		this.btn.click();
	}
	
	public void setUserName(String username) {
		this.UserName.sendKeys(username); 
	}

	public void setPassword(String userpwd) {
		this.UserPwd.sendKeys(userpwd);
	}
	


}
