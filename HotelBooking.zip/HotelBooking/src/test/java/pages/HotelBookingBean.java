package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class HotelBookingBean {

	WebDriver driver;
	
	@FindBy(name="txtFN")
	private WebElement TxtFN;
	@FindBy(name="txtLN")
	private WebElement TxtLN;
	@FindBy(name="Email")
	private WebElement EMail;
	@FindBy(name="Phone")
	private WebElement Phone;
	@FindBy(name="add")
	private WebElement address;
	@FindBy(name="city")
	private WebElement City;
	@FindBy(name="state")
	private WebElement State;
	@FindBy(name="persons")
	private WebElement persons;
	@FindBy(name="rooms")
	private WebElement rooms;
	@FindBy(name="txtFN")
	private WebElement TxtFN1;
	@FindBy(name="debit")
	private WebElement Debit;
	@FindBy(name="cvv")
	private WebElement Cvv;
	@FindBy(name="month")
	private WebElement Month;
	@FindBy(name="year")
	private WebElement Year;
	@FindBy(name="btn")
	private WebElement btn2;
	public HotelBookingBean(WebDriver driver) {
		
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void setBtn2() {
		this.btn2.click();
	}
	
	public void setFirstName(String txtfn) {
		this.TxtFN.sendKeys(txtfn); 
	}

	public void setLastName(String txtln) {
		this.TxtLN.sendKeys(txtln);
	}

	public void setEmail(String email) {
		this.EMail.sendKeys(email);
	}

	public void setPhone(String phone) {
		this.Phone.sendKeys(phone);
	}
	public void setAdd(String addr) {
		this.address.sendKeys(addr);
	}
	/*public String getAddress(String area) {
		return address.getText();
	}*/

	public void setCity(String c) {
		Select sel= new Select(City);
		sel.selectByVisibleText(c);
	}

	public void setState(String s) {
		Select st=new Select(State);
		st.selectByVisibleText(s);
	}

	public void setPersons(String pe) {
		Select p= new Select(persons);
		p.selectByVisibleText(pe);
	}
	public void setRooms(String room) {
		this.rooms.sendKeys(room);
	}
	public void setCardHolderName(String cardHolderName) {
		this.TxtFN1.sendKeys(cardHolderName);
	}
	public void setDbCardNumber(String debitnum) {
		this.Debit.sendKeys(debitnum);
	}
	

	public void setCvv(String cvv) {
		this.Cvv.sendKeys(cvv);
	}

	public void setExpiryDate(String expiryDate) {
		this.Month.sendKeys(expiryDate);
	}

	public void setExpiryYear(String expiryYear) {
		this.Year.sendKeys(expiryYear);
	}
	
	
}
