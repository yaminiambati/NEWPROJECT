function page1()
{   
	var flag = false;
	var firstName=PerosnalDetails.firstName.value;
	if(firstName==null||firstName==""){
		window.alert("Please enter firstName.");
	}	
	else{
		var lastName=PerosnalDetails.lastName.value;
		if(lastName==null||lastName==""){
			window.alert("Please enter lastName.");
		}
		else
			{
			var address = document.getElementById("address").value;
			if(address==null||address==""){
				window.alert("Please enter address.");
			}
			else
				{
				var city=PerosnalDetails.city.value;
				if(city==null||city==""){
					window.alert("Please enter city.");
				}
				else{
					var state=PerosnalDetails.state.value;
					if(state==null||state==""){
						window.alert("Please enter state.");
					}
					else{
						if((!document.getElementById('male').checked)&&(!document.getElementById('female').checked)){
								window.alert("Please enter gender.");
						}
						else
							{
							var course=PerosnalDetails.course.value;
							if(course==null||course==""){
								window.alert("Please enter course.");
							}
							else{
								var mobileNo=PerosnalDetails.mobileNo.value;
								if(mobileNo==null||mobileNo==""){
									window.alert("Please enter mobileNo.");
								}
								else if((mobileNo.length!=10)){
									window.alert("Please enter mobileNo with 10 digits");
								}
								else if(isDigit(mobileNo)){
									window.alert("mobileNo should contain only digits!");
								}
								else
									{
									flag=true;
									window.alert("Personal Details Successfully Entered!");
									}
								}
							}
						}
					}
				}
			}
		}
	return flag;
}

function page2(){
	var flag1 = false;
	var holderName=PaymentDetails.holderName.value;
	if(holderName==null||holderName==""){
		window.alert("Please enter CardholderName.");
	}
	else if(isCaps(holderName)){
		window.alert("CardholderName must in ALL caps");
	}
	else{
		var cardNo=PaymentDetails.cardNo.value;
		if(cardNo==null||holderName==""){
			window.alert("Please enter cardNo.");
		}
		else if((cardNo.length!=16)){
			window.alert("Please enter cardNo with 16 digits");
		}
		else if(isDigit(cardNo)){
			window.alert("cardNo should contain only digits!");
		}
		else{
			var cvvNo=PaymentDetails.cvvNo.value;
			if(cvvNo==null||cvvNo==""){
				window.alert("Please enter cvvNo.");
			}
			else if((cvvNo.length!=3)){
				window.alert("Please enter cvvNo with 3 digits");
			}
			else if(isDigit(cvvNo)){
				window.alert("cvvNo should contain only digits!");
			}
			else{
				var expiry=PaymentDetails.expiry.value;
				if(expiry==null||expiry==""){
					window.alert("Please enter expiry.");
				}
				else{
					flag1=true;
					window.alert("Payment Success!");
				}
			}
		}
	}
	return flag1;
}

function isDigit(str) {
    return /[^\d]/.test(str);
}

function isCaps(str) {
    return /[^A-Z]/g.test(str);
}